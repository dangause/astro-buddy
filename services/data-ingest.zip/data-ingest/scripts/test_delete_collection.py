from src.config import settings
from src.core.utils import delete_collection


if __name__ == '__main__':
    delete_collection()
